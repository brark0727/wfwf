// authService.js
import { apiRequest } from '../utils/apiHelper';
import { API_ENDPOINTS } from '../config/apiConfig';
import { setToken, clearToken } from '../utils/tokenManager';

export const login = async (email, password) => {
  try {
    const data = await apiRequest(API_ENDPOINTS.LOGIN, 'POST', { email, password });
    setToken(data.token);
    return data;
  } catch (error) {
    throw error;
  }
};

export const signUp = async (email, password, username) => {
  try {
    const data = await apiRequest(API_ENDPOINTS.SIGNUP, 'POST', { email, password, username });
    setToken(data.token);
    return data;
  } catch (error) {
    throw error;
  }
};

export const logout = () => {
  clearToken();
};
