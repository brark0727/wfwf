import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppProvider, useAppContext } from './context/AppContext'; 
import LoginPage from './components/LoginPage';
import LocalLoginPage from './components/LocalLoginPage';
import RegisterPage from './components/RegisterPage';
import Calendar from './components/Calendar';
import TodoList from './components/TodoList';
import Header from './components/Header';
import './App.css';

const MainApp = () => {
  const { user, setUser, setToken } = useAppContext();

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    if (code) {
      exchangeCodeForToken(code);
    }
  }, []);

  const exchangeCodeForToken = async (code) => {
    try {
      const response = await fetch('http://localhost:8080/auth/kakao', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code })
      });
      const data = await response.json();
      setToken(data.accessToken);
      localStorage.setItem('token', data.accessToken);
      fetchUser(data.accessToken);
    } catch (error) {
      console.error('Failed to exchange code for token:', error);
    }
  };

  const fetchUser = async (token) => {
    try {
      const response = await fetch('http://localhost:8080/api/user', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const userData = await response.json();
      setUser(userData);
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  return user ? (
    <div className="app-container">
      <Header />
      <div className="main-content">
        <Calendar />
        <TodoList />
      </div>
    </div>
  ) : (
    <LoginPage />
  );
};

function App() {
  return (
    <AppProvider>
      <Router>
        <Routes>
          <Route path="/" element={<MainApp />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/local-login" element={<LocalLoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Routes>
      </Router>
    </AppProvider>
  );
}

export default App;
