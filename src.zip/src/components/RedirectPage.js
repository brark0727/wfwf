import React, { useEffect } from 'react';
import { useHistory } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';

const RedirectPage = () => {
  const history = useHistory();
  const { setToken } = useAppContext();

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    if (token) {
      setToken(token);
      localStorage.setItem('token', token);
      history.push('/main'); // 메인 페이지로 리다이렉션
    } else {
      history.push('/login'); // 토큰이 없으면 로그인 페이지로 리다이렉션
    }
  }, [history, setToken]);

  return (
    <div>Loading...</div>
  );
};

export default RedirectPage;
