import React from 'react';

function MainContent() {
  return <div>메인 콘텐츠 영역입니다. 여기에 다양한 정보를 표시할 수 있습니다.</div>;
}

export default MainContent;
