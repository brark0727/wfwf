// src/components/TodoList.js
import React, { useState, useEffect } from 'react';
import { useAppContext } from '../context/AppContext';
import './TodoList.css';

function TodoList() {
  const { selectedDate, setSelectedDate, todos, setTodos, addTodo, completeTodo, deleteTodo, user, status } = useAppContext(); // setSelectedDate 추가
  const [newTodo, setNewTodo] = useState('');

  useEffect(() => {
    fetchTodos();
  }, []);

  const fetchTodos = async () => {
    try {
      const response = await fetch('http://localhost:3000/todo');
      const data = await response.json();
      setTodos(data);
    } catch (error) {
      console.error('Failed to fetch todos:', error);
    }
  };

  const fetchTodosByDate = async (date) => {
    try {
      const response = await fetch(`http://localhost:3000/todo/${date}`);
      const data = await response.json();
      setTodos(data);
    } catch (error) {
      console.error('Failed to fetch todos by date:', error);
    }
  };

  const handleDateClick = (date) => {
    fetchTodosByDate(date);
    setSelectedDate(new Date(date));
  };

  const handleAddTodo = () => {
    if (newTodo.trim()) {
      addTodo({
        date: new Date(selectedDate), // 날짜 객체가 올바르게 설정되었는지 확인
        text: newTodo,
        completed: false,
      });
      setNewTodo('');
    }
  };

  const handleInputChange = (e) => {
    setNewTodo(e.target.value);
  };

  const handleSave = async () => {
    const data = {
      todos,
      status,
      user,
    };

    try {
      const response = await fetch('http://localhost:3000/todo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      console.log('Save successful:', result);
    } catch (error) {
      console.error('Save failed:', error);
    }
  };

  const handleLoad = async () => {
    try {
      const response = await fetch('http://localhost:3000/read-json');
      const data = await response.json();
      setTodos(data);
      console.log('Load successful:', data);
    } catch (error) {
      console.error('Load failed:', error);
    }
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const mainTodos = todos.filter(todo => {
    const todoDate = new Date(todo.date);
    todoDate.setHours(0, 0, 0, 0);
    return todoDate.getTime() === selectedDate.getTime();
  });

  const subTodos = todos.filter(todo => {
    const todoDate = new Date(todo.date);
    todoDate.setHours(0, 0, 0, 0);
    return todoDate.getTime() > selectedDate.getTime() && selectedDate.getTime() >= today.getTime();
  });

  return (
    <div className="todo-container">
      <h2>{selectedDate.toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })}</h2>
      <div className="todo-input">
        <input type="text" value={newTodo} onChange={handleInputChange} placeholder="Add Todo here" />
        <button onClick={handleAddTodo}>+</button>
      </div>
      <div className="todo-columns">
        <div className="todo-main">
          <h3>Main</h3>
          <ul>
            {mainTodos.map((todo, index) => (
              <li key={index}>
                <input type="checkbox" checked={todo.completed} onChange={() => completeTodo(todo.id)} />
                <span className={todo.completed ? 'completed' : ''}>{todo.text}</span>
                <button onClick={() => deleteTodo(todo.id)}>삭제</button>
              </li>
            ))}
          </ul>
        </div>
        <div className="todo-sub">
          <h3>Sub</h3>
          <ul>
            {subTodos.map((todo, index) => (
              <li key={index}>
                <input type="checkbox" checked={todo.completed} onChange={() => completeTodo(todo.id)} />
                <span className={todo.completed ? 'completed' : ''}>
                  {todo.text} ({new Date(todo.date).toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' })})
                </span>
                <button onClick={() => deleteTodo(todo.id)}>삭제</button>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <button onClick={handleSave} style={{ position: 'absolute', bottom: '20px', right: '20px', padding: '10px 20px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
        저장
      </button>
      <button onClick={handleLoad} style={{ position: 'absolute', bottom: '60px', right: '20px', padding: '10px 20px', backgroundColor: '#2196F3', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}>
        불러오기
      </button>
    </div>
  );
}

export default TodoList;
