import React from 'react';
import { useNavigate } from 'react-router-dom'; // 페이지 이동을 위해 useNavigate 훅 사용

const KAKAO_CLIENT_ID = '23827fd482106a8b5f9298aaaaf39951'; // 클라이언트 ID 직접 명시
const REDIRECT_URI = 'http://localhost:8080/oauth2/authorization/kakao'; // 리다이렉트 URI 직접 명시

const LoginPage = () => {
  const navigate = useNavigate(); // 리액트 라우터의 네비게이트 객체

  const handleKakaoLogin = () => {
    window.location.href = `https://kauth.kakao.com/oauth/authorize?client_id=${KAKAO_CLIENT_ID}&redirect_uri=${REDIRECT_URI}&response_type=code`;
  };

  const handleLocalLogin = () => {
    navigate('/local-login'); // 일반 로그인 페이지로 이동
  };

  const handleRegister = () => {
    navigate('/register'); // 회원가입 페이지로 이동
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <button onClick={handleKakaoLogin}>Login with Kakao</button>
      <button onClick={handleLocalLogin}>Local Login</button>
      <button onClick={handleRegister}>Register</button> {/* 회원가입 버튼 추가 */}
    </div>
  );
};

export default LoginPage;
