// apiHelper.js
export async function apiRequest(url, method = 'GET', body = null) {
  const headers = new Headers({
    'Content-Type': 'application/json'
  });

  const config = {
    method: method,
    headers: headers,
    body: body ? JSON.stringify(body) : null,
  };

  try {
    const response = await fetch(url, config);
    if (!response.ok) {
      const errorData = await response.json(); // 에러 응답을 JSON으로 파싱
      throw new Error(`HTTP error! status: ${response.status}, message: ${errorData.message}`);
    }
    return await response.json();
  } catch (error) {
    console.error("Error making request:", error);
    throw error;
  }
}
